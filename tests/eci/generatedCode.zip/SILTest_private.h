/*
 * File: SILTest_private.h
 *
 * Code generated for Simulink model 'SILTest'.
 *
 * Model version                  : 1.20
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Fri Apr  5 10:32:43 2019
 *
 * Target selection: cfs_ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_SILTest_private_h_
#define RTW_HEADER_SILTest_private_h_
#include "rtwtypes.h"

extern ECI_TimeStamp_t ECI_Step_TimeStamp;

/* Exported data declaration */

/* Declaration of data with custom storage class cfsParmTable */
extern Tbl_b *Tbl ;

#endif                                 /* RTW_HEADER_SILTest_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

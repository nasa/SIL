/*
 * File: OutBus_1_b.h
 *
 * Code generated for Simulink model 'SILTest'.
 *
 * Model version                  : 1.20
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Fri Apr  5 10:32:43 2019
 *
 * Target selection: cfs_ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_OutBus_1_b_h_
#define RTW_HEADER_OutBus_1_b_h_
#include "rtwtypes.h"

/* No description provided */
typedef struct {
  uint8_T Field1[8];
  uint16_T Field2[4];
  real32_T Field3[2];
  real_T Field4;
} OutBus_1_b;

#endif                                 /* RTW_HEADER_OutBus_1_b_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

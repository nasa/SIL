/*
 * File: Tbl_b.h
 *
 * Code generated for Simulink model 'SILTest'.
 *
 * Model version                  : 1.66
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Thu Dec  5 14:05:30 2019
 *
 * Target selection: cfs_ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Tbl_b_h_
#define RTW_HEADER_Tbl_b_h_
#include "rtwtypes.h"

typedef struct {
  real_T Param1;
  uint8_T Param2[2];
  real32_T Param3;
} Tbl_b;

#endif                                 /* RTW_HEADER_Tbl_b_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

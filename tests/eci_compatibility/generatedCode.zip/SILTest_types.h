/*
 * File: SILTest_types.h
 *
 * Code generated for Simulink model 'SILTest'.
 *
 * Model version                  : 1.66
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Thu Dec  5 14:05:30 2019
 *
 * Target selection: cfs_ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_SILTest_types_h_
#define RTW_HEADER_SILTest_types_h_
#include "InTlmBus.h"
#include "InCmdBus.h"
#include "CdsDataBus.h"
#include "AyncMsgBus.h"
#include "ConditionalMsgBus.h"
#include "PeriodicMsgBus.h"
#include "EventMsgBus.h"
#include "ParamTblBus.h"
#include "Tbl_b.h"
#include "StatusFlagBus.h"
#include "TimeBus.h"

/* Forward declaration for rtModel */
typedef struct tag_RTM_SILTest_T RT_MODEL_SILTest_T;

#endif                                 /* RTW_HEADER_SILTest_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

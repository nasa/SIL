/*
 * File: SILTest.c
 *
 * Code generated for Simulink model 'SILTest'.
 *
 * Model version                  : 1.66
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Thu Dec  5 14:05:30 2019
 *
 * Target selection: cfs_ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "SILTest.h"
#include "SILTest_private.h"

const InTlmBus SILTest_rtZInTlmBus = {
  {
    {
      0U, 0U }
    ,                                  /* StreamID */

    {
      0U, 0U }
    ,                                  /* Sequence */

    {
      0U, 0U }
    ,                                  /* PktLen */

    {
      0U, 0U }
    ,                                  /* Time_sec */
    0U                                 /* Time_subsec */
  },                                   /* Header */
  0U,                                  /* AsyncInputVal */
  0U,                                  /* StatusFlagInputVal */
  0.0,                                 /* CDSInputVal */
  0U                                   /* EventInputVal */
} ;                                    /* InTlmBus ground */

const InCmdBus SILTest_rtZInCmdBus = {
  {
    {
      0U, 0U }
    ,                                  /* StreamID */

    {
      0U, 0U }
    ,                                  /* Sequence */

    {
      0U, 0U }
    ,                                  /* PktLen */
    0U,                                /* FcnCode */
    0U                                 /* ChkSum */
  },                                   /* Header */
  0.0                                  /* Arg1 */
} ;                                    /* InCmdBus ground */

const CdsDataBus SILTest_rtZCdsDataBus = {
  0U,                                  /* saved_counter_value */
  0U,                                  /* unsaved_counter_value */
  0.0,                                 /* accumulator_input */
  0.0,                                 /* saved_accumulator_value */
  0.0                                  /* unsaved_accumulator_value */
} ;                                    /* CdsDataBus ground */

const AyncMsgBus SILTest_rtZAyncMsgBus = {
  0U                                   /* conditional_value */
} ;                                    /* AyncMsgBus ground */

const ConditionalMsgBus SILTest_rtZConditionalMsgBus = {
  false,                               /* sent_periodic_message */
  0U,                                  /* cycle_counter */
  false,                               /* sent_asyc_message */
  0U                                   /* conditional_value */
} ;                                    /* ConditionalMsgBus ground */

const PeriodicMsgBus SILTest_rtZPeriodicMsgBus = {
  0U                                   /* cycle_counter */
} ;                                    /* PeriodicMsgBus ground */

const EventMsgBus SILTest_rtZEventMsgBus = {
  false,                               /* sending_event1 */
  false,                               /* sending_event2 */
  0.0,                                 /* evt1_value1 */
  0.0,                                 /* evt1_value2 */
  0.0,                                 /* evt1_value3 */
  0.0                                  /* evt2_value1 */
} ;                                    /* EventMsgBus ground */

const StatusFlagBus SILTest_rtZStatusFlagBus = {
  false,                               /* flag_set */
  0U                                   /* input_value */
} ;                                    /* StatusFlagBus ground */

const TimeBus SILTest_rtZTimeBus = {
  0.0,                                 /* fsw_time */
  0.0                                  /* elapsed_sim_time */
} ;                                    /* TimeBus ground */

/* Exported block states */
real_T evData_SILTest_7[5];            /* '<S3>/CFS_Event' */
real_T evData_SILTest_125[5];          /* '<S3>/CFS_Event1' */
boolean_T cmsgFlag_SILTest_5;          /* '<S2>/PeriodicMessage' */
boolean_T cmsgFlag_SILTest_60;         /* '<S2>/AsyncMessage' */
boolean_T evFlag_SILTest_7;            /* '<S3>/CFS_Event' */
boolean_T evFlag_SILTest_125;          /* '<S3>/CFS_Event1' */
boolean_T fdcFlag_6;                   /* '<S5>/CFS_Status_Flag' */

/* Exported data definition */

/* Definition of data with custom storage class cfsCmdMessage */
InCmdBus InCmdBus_s;

/* Definition of data with custom storage class cfsCriticalDataStorage */
static real_T double_accumulator_state;
static uint8_T uint8_counter_state;

/* Definition of data with custom storage class cfsTlmMessage */
AyncMsgBus AyncMsgBus_s;
CdsDataBus CdsDataBus_s;
ConditionalMsgBus ConditionalMsgBus_s;
EventMsgBus EventMsgBus_s;
InTlmBus InTlmBus_s;
PeriodicMsgBus PerodicMsgBus_s;
StatusFlagBus StatusFlagBus_s;
TimeBus TimeBus_s;

/* Block signals (default storage) */
B_SILTest_T SILTest_B;

/* Block states (default storage) */
DW_SILTest_T SILTest_DW;

/* External outputs (root outports fed by signals with default storage) */
ExtY_SILTest_T SILTest_Y;

/* Real-time model */
RT_MODEL_SILTest_T SILTest_M_;
RT_MODEL_SILTest_T *const SILTest_M = &SILTest_M_;

/* Model step function */
void SILTest_step(void)
{
  uint8_T y;

  /* BusCreator: '<S4>/Bus Creator' incorporates:
   *  Constant: '<S4>/Constant'
   *  Constant: '<S4>/Constant1'
   *  Constant: '<S4>/Constant2'
   *  Outport: '<Root>/ParamTblBus'
   */
  SILTest_Y.ParamTblBus_l.param1 = (*Tbl).Param1;
  SILTest_Y.ParamTblBus_l.param2[0] = (*Tbl).Param2[0];
  SILTest_Y.ParamTblBus_l.param2[1] = (*Tbl).Param2[1];
  SILTest_Y.ParamTblBus_l.param3 = (*Tbl).Param3;

  /* Sum: '<S13>/Add' incorporates:
   *  Constant: '<S13>/Constant'
   *  UnitDelay: '<S13>/Unit Delay'
   */
  SILTest_DW.UnitDelay_DSTATE_f++;

  /* Math: '<S2>/Mod' incorporates:
   *  UnitDelay: '<S13>/Unit Delay'
   */
  if (SILTest_DW.UnitDelay_DSTATE_f == 0) {
    y = 10U;
  } else {
    y = (uint8_T)(10 % SILTest_DW.UnitDelay_DSTATE_f);
  }

  /* End of Math: '<S2>/Mod' */

  /* RelationalOperator: '<S12>/Compare' incorporates:
   *  Constant: '<S12>/Constant'
   */
  SILTest_B.Compare = (y == 0);

  /* BusCreator: '<S2>/Bus Creator2' incorporates:
   *  UnitDelay: '<S13>/Unit Delay'
   */
  SILTest_B.BusCreator2.cycle_counter = SILTest_DW.UnitDelay_DSTATE_f;

  /* S-Function (cfs_conditional_msg): '<S2>/PeriodicMessage' */
  cmsgFlag_SILTest_5 = SILTest_B.Compare;
  if (cmsgFlag_SILTest_5) {
    PerodicMsgBus_s = SILTest_B.BusCreator2;
  }

  /* RelationalOperator: '<S11>/Compare' incorporates:
   *  Constant: '<S11>/Constant'
   *  Inport: '<Root>/Inport'
   */
  SILTest_B.Compare_h = (InTlmBus_s.AsyncInputVal == 3);

  /* BusCreator: '<S2>/Bus Creator1' incorporates:
   *  Inport: '<Root>/Inport'
   */
  SILTest_B.BusCreator1.conditional_value = InTlmBus_s.AsyncInputVal;

  /* S-Function (cfs_conditional_msg): '<S2>/AsyncMessage' */
  cmsgFlag_SILTest_60 = SILTest_B.Compare_h;
  if (cmsgFlag_SILTest_60) {
    AyncMsgBus_s = SILTest_B.BusCreator1;
  }

  /* RelationalOperator: '<S14>/Compare' incorporates:
   *  Constant: '<S14>/Constant'
   *  Inport: '<Root>/Inport'
   */
  SILTest_B.Compare_g = (InTlmBus_s.EventInputVal == 65535);

  /* DataTypeConversion: '<S3>/toDouble' incorporates:
   *  Inport: '<Root>/Inport'
   */
  SILTest_B.evt1_value1 = InTlmBus_s.EventInputVal;

  /* Gain: '<S3>/Gain' */
  SILTest_B.evt1_value2 = 2.0 * SILTest_B.evt1_value1;

  /* Gain: '<S3>/Gain1' */
  SILTest_B.evt1_value3 = 2.0 * SILTest_B.evt1_value2;

  /* S-Function (cfs_event): '<S3>/CFS_Event' */
  evFlag_SILTest_7 = SILTest_B.Compare_g;
  evData_SILTest_7[0] = SILTest_B.evt1_value1;
  evData_SILTest_7[1] = SILTest_B.evt1_value2;

  /* RelationalOperator: '<S15>/FixPt Relational Operator' incorporates:
   *  Inport: '<Root>/InCmdBus'
   *  UnitDelay: '<S15>/Delay Input1'
   *
   * Block description for '<S15>/Delay Input1':
   *
   *  Store in Global RAM
   */
  SILTest_B.FixPtRelationalOperator = (InCmdBus_s.Arg1 !=
    SILTest_DW.DelayInput1_DSTATE);

  /* S-Function (cfs_event): '<S3>/CFS_Event1' incorporates:
   *  Inport: '<Root>/InCmdBus'
   */
  evFlag_SILTest_125 = SILTest_B.FixPtRelationalOperator;

  /* RelationalOperator: '<S16>/Compare' incorporates:
   *  Constant: '<S16>/Constant'
   *  Inport: '<Root>/Inport'
   */
  SILTest_B.Compare_l = (InTlmBus_s.StatusFlagInputVal == 4);

  /* S-Function (cfs_fdc): '<S5>/CFS_Status_Flag' */
  fdcFlag_6 = SILTest_B.Compare_l;

  /* BusCreator: '<S6>/Bus Creator' incorporates:
   *  DigitalClock: '<S6>/Digital Clock'
   *  S-Function (cfs_gnc_time): '<S6>/CFS_Time'
   */
  TimeBus_s.fsw_time = ((real_T)ECI_Step_TimeStamp.Seconds + ((real_T)
    ECI_Step_TimeStamp.Subseconds/4294967296.0));
  TimeBus_s.elapsed_sim_time = ((SILTest_M->Timing.clockTick0) * 0.1);

  /* BusCreator: '<S5>/Bus Creator' incorporates:
   *  Inport: '<Root>/Inport'
   */
  StatusFlagBus_s.flag_set = SILTest_B.Compare_l;
  StatusFlagBus_s.input_value = InTlmBus_s.StatusFlagInputVal;

  /* BusCreator: '<S3>/Bus Creator' incorporates:
   *  Inport: '<Root>/InCmdBus'
   */
  EventMsgBus_s.sending_event1 = SILTest_B.Compare_g;
  EventMsgBus_s.sending_event2 = SILTest_B.FixPtRelationalOperator;
  EventMsgBus_s.evt1_value1 = SILTest_B.evt1_value1;
  EventMsgBus_s.evt1_value2 = SILTest_B.evt1_value2;
  EventMsgBus_s.evt1_value3 = SILTest_B.evt1_value3;
  EventMsgBus_s.evt2_value1 = InCmdBus_s.Arg1;

  /* BusCreator: '<S2>/Bus Creator' incorporates:
   *  Inport: '<Root>/Inport'
   *  UnitDelay: '<S13>/Unit Delay'
   */
  ConditionalMsgBus_s.sent_periodic_message = SILTest_B.Compare;
  ConditionalMsgBus_s.cycle_counter = SILTest_DW.UnitDelay_DSTATE_f;
  ConditionalMsgBus_s.sent_asyc_message = SILTest_B.Compare_h;
  ConditionalMsgBus_s.conditional_value = InTlmBus_s.AsyncInputVal;

  /* Sum: '<S9>/Add' incorporates:
   *  Constant: '<S9>/Constant'
   *  UnitDelay: '<S9>/Unit Delay'
   */
  uint8_counter_state = (uint8_T)(1U + uint8_counter_state);

  /* Sum: '<S10>/Add' incorporates:
   *  Constant: '<S10>/Constant'
   *  UnitDelay: '<S10>/Unit Delay'
   */
  SILTest_DW.UnitDelay_DSTATE_k++;

  /* Sum: '<S8>/Add' incorporates:
   *  Inport: '<Root>/Inport'
   *  UnitDelay: '<S8>/Unit Delay'
   */
  double_accumulator_state = InTlmBus_s.CDSInputVal + double_accumulator_state;

  /* Sum: '<S7>/Add' incorporates:
   *  Inport: '<Root>/Inport'
   *  UnitDelay: '<S7>/Unit Delay'
   */
  SILTest_DW.UnitDelay_DSTATE += InTlmBus_s.CDSInputVal;

  /* BusCreator: '<S1>/Bus Creator' incorporates:
   *  Inport: '<Root>/Inport'
   *  UnitDelay: '<S10>/Unit Delay'
   *  UnitDelay: '<S7>/Unit Delay'
   *  UnitDelay: '<S8>/Unit Delay'
   *  UnitDelay: '<S9>/Unit Delay'
   */
  CdsDataBus_s.saved_counter_value = uint8_counter_state;
  CdsDataBus_s.unsaved_counter_value = SILTest_DW.UnitDelay_DSTATE_k;
  CdsDataBus_s.accumulator_input = InTlmBus_s.CDSInputVal;
  CdsDataBus_s.saved_accumulator_value = double_accumulator_state;
  CdsDataBus_s.unsaved_accumulator_value = SILTest_DW.UnitDelay_DSTATE;

  /* Update for UnitDelay: '<S15>/Delay Input1' incorporates:
   *  Inport: '<Root>/InCmdBus'
   *
   * Block description for '<S15>/Delay Input1':
   *
   *  Store in Global RAM
   */
  SILTest_DW.DelayInput1_DSTATE = InCmdBus_s.Arg1;

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The resolution of this integer timer is 0.1, which is the step size
   * of the task. Size of "clockTick0" ensures timer will not overflow during the
   * application lifespan selected.
   */
  SILTest_M->Timing.clockTick0++;
}

/* Model initialize function */
void SILTest_initialize(void)
{
  /* Registration code */

  /* initialize real-time model */
  (void) memset((void *)SILTest_M, 0,
                sizeof(RT_MODEL_SILTest_T));

  /* block I/O */
  (void) memset(((void *) &SILTest_B), 0,
                sizeof(B_SILTest_T));

  /* custom signals */
  EventMsgBus_s = SILTest_rtZEventMsgBus;
  CdsDataBus_s = SILTest_rtZCdsDataBus;
  TimeBus_s = SILTest_rtZTimeBus;
  StatusFlagBus_s = SILTest_rtZStatusFlagBus;
  PerodicMsgBus_s = SILTest_rtZPeriodicMsgBus;
  ConditionalMsgBus_s = SILTest_rtZConditionalMsgBus;
  AyncMsgBus_s = SILTest_rtZAyncMsgBus;

  /* states (dwork) */
  (void) memset((void *)&SILTest_DW, 0,
                sizeof(DW_SILTest_T));

  /* exported global states */
  (void) memset(&evData_SILTest_7, 0,
                5U*sizeof(real_T));
  (void) memset(&evData_SILTest_125, 0,
                5U*sizeof(real_T));
  cmsgFlag_SILTest_5 = false;
  cmsgFlag_SILTest_60 = false;
  evFlag_SILTest_7 = false;
  evFlag_SILTest_125 = false;
  fdcFlag_6 = false;

  /* custom states */
  double_accumulator_state = 0.0;
  uint8_counter_state = 0U;

  /* external inputs */
  InTlmBus_s = SILTest_rtZInTlmBus;
  InCmdBus_s = SILTest_rtZInCmdBus;

  /* external outputs */
  (void) memset((void *)&SILTest_Y, 0,
                sizeof(ExtY_SILTest_T));

  /* InitializeConditions for S-Function (cfs_conditional_msg): '<S2>/PeriodicMessage' */
  cmsgFlag_SILTest_5 = false;

  /* InitializeConditions for S-Function (cfs_conditional_msg): '<S2>/AsyncMessage' */
  cmsgFlag_SILTest_60 = false;
}

/* Model terminate function */
void SILTest_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

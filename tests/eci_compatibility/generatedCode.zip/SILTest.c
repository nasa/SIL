/*
 * File: SILTest.c
 *
 * Code generated for Simulink model 'SILTest'.
 *
 * Model version                  : 1.20
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Fri Aug 23 13:52:38 2019
 *
 * Target selection: cfs_ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "SILTest.h"
#include "SILTest_private.h"

const InBus_1_b SILTest_rtZInBus_1_b = {
  {
    0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
  ,                                    /* Field1 */

  {
    0U, 0U, 0U, 0U }
  ,                                    /* Field2 */

  {
    0.0F, 0.0F }
  ,                                    /* Field3 */
  0.0                                  /* Field4 */
} ;                                    /* InBus_1_b ground */

const OutBus_2_b SILTest_rtZOutBus_2_b = {
  {
    0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
  ,                                    /* Field1 */

  {
    0U, 0U, 0U, 0U }
  ,                                    /* Field2 */

  {
    0.0F, 0.0F }
  ,                                    /* Field3 */
  0.0                                  /* Field4 */
} ;                                    /* OutBus_2_b ground */

const OutBus_1_b SILTest_rtZOutBus_1_b = {
  {
    0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
  ,                                    /* Field1 */

  {
    0U, 0U, 0U, 0U }
  ,                                    /* Field2 */

  {
    0.0F, 0.0F }
  ,                                    /* Field3 */
  0.0                                  /* Field4 */
} ;                                    /* OutBus_1_b ground */

/* Exported block states */
real_T evData_SILTest_7[5];            /* '<Root>/CFS_Event' */
boolean_T cmsgFlag_SILTest_5;          /* '<Root>/CFS_Conditional_Msg' */
boolean_T evFlag_SILTest_7;            /* '<Root>/CFS_Event' */
boolean_T fdcFlag_6;                   /* '<Root>/CFS_Status_Flag' */

/* Exported data definition */

/* Definition of data with custom storage class cfsTlmMessage */
InBus_1_b InBus1_s;
OutBus_1_b OutBus1_s;
OutBus_2_b OutBus2_s;

/* Block signals (default storage) */
B_SILTest_T SILTest_B;

/* Block states (default storage) */
DW_SILTest_T SILTest_DW;

/* Real-time model */
RT_MODEL_SILTest_T SILTest_M_;
RT_MODEL_SILTest_T *const SILTest_M = &SILTest_M_;

/* Model step function */
void SILTest_step(void)
{
  int32_T i;

  /* BusCreator: '<Root>/Bus Creator1' incorporates:
   *  Constant: '<Root>/Constant1'
   *  Inport: '<Root>/Inport'
   */
  for (i = 0; i < 8; i++) {
    OutBus1_s.Field1[i] = InBus1_s.Field1[i];
  }

  OutBus1_s.Field2[0] = InBus1_s.Field2[0];
  OutBus1_s.Field2[1] = InBus1_s.Field2[1];
  OutBus1_s.Field2[2] = InBus1_s.Field2[2];
  OutBus1_s.Field2[3] = InBus1_s.Field2[3];
  OutBus1_s.Field3[0] = InBus1_s.Field3[0];
  OutBus1_s.Field3[1] = InBus1_s.Field3[1];
  OutBus1_s.Field4 = (*Tbl).Param1;

  /* End of BusCreator: '<Root>/Bus Creator1' */

  /* DataTypeConversion: '<Root>/Data Type Conversion' incorporates:
   *  Inport: '<Root>/Inport'
   */
  SILTest_B.DataTypeConversion = (InBus1_s.Field1[0] != 0);

  /* S-Function (cfs_gnc_time): '<Root>/CFS_Time' */
  SILTest_B.Field4 = ((real_T)ECI_Step_TimeStamp.Seconds + ((real_T)
    ECI_Step_TimeStamp.Subseconds/4294967296.0));

  /* BusCreator: '<Root>/Bus Creator' incorporates:
   *  Inport: '<Root>/Inport'
   */
  for (i = 0; i < 8; i++) {
    SILTest_B.BusCreator.Field1[i] = InBus1_s.Field1[i];
  }

  SILTest_B.BusCreator.Field2[0] = InBus1_s.Field2[0];
  SILTest_B.BusCreator.Field2[1] = InBus1_s.Field2[1];
  SILTest_B.BusCreator.Field2[2] = InBus1_s.Field2[2];
  SILTest_B.BusCreator.Field2[3] = InBus1_s.Field2[3];
  SILTest_B.BusCreator.Field3[0] = InBus1_s.Field3[0];
  SILTest_B.BusCreator.Field3[1] = InBus1_s.Field3[1];
  SILTest_B.BusCreator.Field4 = SILTest_B.Field4;

  /* End of BusCreator: '<Root>/Bus Creator' */

  /* S-Function (cfs_conditional_msg): '<Root>/CFS_Conditional_Msg' */
  cmsgFlag_SILTest_5 = SILTest_B.DataTypeConversion;
  if (cmsgFlag_SILTest_5) {
    OutBus2_s = SILTest_B.BusCreator;
  }

  /* DataTypeConversion: '<Root>/Data Type Conversion2' incorporates:
   *  Inport: '<Root>/Inport'
   */
  SILTest_B.DataTypeConversion2 = (InBus1_s.Field1[2] != 0);

  /* S-Function (cfs_event): '<Root>/CFS_Event' incorporates:
   *  Constant: '<Root>/Constant'
   *  Inport: '<Root>/Inport'
   */
  evFlag_SILTest_7 = SILTest_B.DataTypeConversion2;
  evData_SILTest_7[0] = SILTest_B.Field4;
  evData_SILTest_7[1] = InBus1_s.Field4;

  /* DataTypeConversion: '<Root>/Data Type Conversion1' incorporates:
   *  Inport: '<Root>/Inport'
   */
  SILTest_B.DataTypeConversion1 = (InBus1_s.Field1[1] != 0);

  /* S-Function (cfs_fdc): '<Root>/CFS_Status_Flag' */
  fdcFlag_6 = SILTest_B.DataTypeConversion1;
}

/* Model initialize function */
void SILTest_initialize(void)
{
  /* Registration code */

  /* initialize error status */
  rtmSetErrorStatus(SILTest_M, (NULL));

  /* block I/O */
  (void) memset(((void *) &SILTest_B), 0,
                sizeof(B_SILTest_T));

  /* custom signals */
  OutBus2_s = SILTest_rtZOutBus_2_b;
  OutBus1_s = SILTest_rtZOutBus_1_b;

  /* states (dwork) */
  (void) memset((void *)&SILTest_DW, 0,
                sizeof(DW_SILTest_T));

  /* exported global states */
  (void) memset(&evData_SILTest_7, 0,
                5U*sizeof(real_T));
  cmsgFlag_SILTest_5 = false;
  evFlag_SILTest_7 = false;
  fdcFlag_6 = false;

  /* external inputs */
  InBus1_s = SILTest_rtZInBus_1_b;

  /* InitializeConditions for S-Function (cfs_conditional_msg): '<Root>/CFS_Conditional_Msg' */
  cmsgFlag_SILTest_5 = false;
}

/* Model terminate function */
void SILTest_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

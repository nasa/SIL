/*
 * File: Tbl.c
 *
 * Code generated for Simulink model 'SILTest'.
 *
 * Model version                  : 1.66
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Tue Dec 17 09:29:03 2019
 *
 * Target selection: cfs_ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "SILTest_types.h"
#include "eci_tbl_if.h"

Tbl_b Tbl = {
  1.0,

  { 0U, 1U },
  10.0F
} ;

#define TBL_TBL_NAME_LEN               (4)                       /* sizeof("Tbl") */
#if TBL_TBL_NAME_LEN > ECI_PARAM_TBL_MAX_NAME_LEN
#error Table name Tbl must be less than ECI_PARAM_TBL_MAX_NAME_LEN characters
#endif

/*
 ** The macro below identifies:
 **    1) the data structure type to use as the table image format
 **    2) the full name of the table to be placed into the CFS Table File Header (ie, appName.tableName)
 **    3) a brief description of the contents of the file image
 **    4) the desired name of the table image binary file that is CFS compatible
 */
ECI_TBL_FILEDEF(CFE_TBL_FileDef, Tbl, SILTest.Tbl, SILTest Tbl, Tbl.tbl )
/*
 * File trailer for generated code.
 *
 * [EOF]
 */

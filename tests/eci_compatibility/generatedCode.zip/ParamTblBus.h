/*
 * File: ParamTblBus.h
 *
 * Code generated for Simulink model 'SILTest'.
 *
 * Model version                  : 1.66
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Thu Dec  5 14:05:30 2019
 *
 * Target selection: cfs_ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_ParamTblBus_h_
#define RTW_HEADER_ParamTblBus_h_
#include "rtwtypes.h"

/* No description provided */
typedef struct {
  /* 8 bit integer clock for comparison to counter */
  real_T param1;

  /* Value of counter whose state is stored in CDS */
  uint8_T param2[2];

  /* Input to accumulator on current cycle */
  real32_T param3;
} ParamTblBus;

#endif                                 /* RTW_HEADER_ParamTblBus_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

/*
 * File: SILTest_data.c
 *
 * Code generated for Simulink model 'SILTest'.
 *
 * Model version                  : 1.20
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Wed Jul 24 14:14:29 2019
 *
 * Target selection: cfs_ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "SILTest.h"
#include "SILTest_private.h"

/* Constant parameters (default storage) */
const ConstP_SILTest_T SILTest_ConstP = {
  /* Expression: event_mask
   * Referenced by: '<Root>/CFS_Event'
   */
  0U,

  /* Pooled Parameter (Expression: )
   * Referenced by:
   *   '<Root>/CFS_Event'
   *   '<Root>/CFS_Status_Flag'
   */
  14U,

  /* Computed Parameter: CFS_Event_event_type
   * Referenced by: '<Root>/CFS_Event'
   */
  12U,

  /* Expression: fmt_string
   * Referenced by: '<Root>/CFS_Event'
   */
  { 76U, 111U, 99U, 58U, 32U, 37U, 115U, 44U, 32U, 37U, 102U, 32U, 37U, 101U,
    32U, 37U, 101U, 32U, 0U }
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

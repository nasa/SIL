/*
 * File: SILTest_data.c
 *
 * Code generated for Simulink model 'SILTest'.
 *
 * Model version                  : 1.66
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Tue Dec 17 09:29:03 2019
 *
 * Target selection: cfs_ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "SILTest.h"
#include "SILTest_private.h"

/* Constant parameters (default storage) */
const ConstP_SILTest_T SILTest_ConstP = {
  /* Pooled Parameter (Expression: event_mask)
   * Referenced by:
   *   '<S3>/CFS_Event'
   *   '<S3>/CFS_Event1'
   */
  1U,

  /* Computed Parameter: CFS_Event_event_id
   * Referenced by: '<S3>/CFS_Event'
   */
  10U,

  /* Pooled Parameter (Expression: )
   * Referenced by:
   *   '<S3>/CFS_Event'
   *   '<S3>/CFS_Event1'
   *   '<S5>/CFS_Status_Flag'
   */
  1U,

  /* Expression: fmt_string
   * Referenced by: '<S3>/CFS_Event'
   */
  { 76U, 111U, 99U, 58U, 32U, 37U, 115U, 44U, 32U, 86U, 97U, 108U, 117U, 101U,
    58U, 32U, 37U, 102U, 44U, 32U, 86U, 97U, 108U, 117U, 101U, 42U, 50U, 58U,
    32U, 37U, 102U, 44U, 32U, 86U, 97U, 108U, 117U, 101U, 42U, 52U, 58U, 32U,
    37U, 102U, 0U },

  /* Computed Parameter: CFS_Event1_event_id
   * Referenced by: '<S3>/CFS_Event1'
   */
  11U,

  /* Expression: fmt_string
   * Referenced by: '<S3>/CFS_Event1'
   */
  { 76U, 111U, 99U, 58U, 32U, 37U, 115U, 44U, 32U, 67U, 111U, 109U, 109U, 97U,
    110U, 100U, 32U, 97U, 114U, 103U, 117U, 109U, 101U, 110U, 116U, 32U, 118U,
    97U, 108U, 117U, 101U, 58U, 32U, 37U, 102U, 0U }
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

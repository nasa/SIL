/*
 * File: eci_interface.h
 *
 * Code generated for Simulink model 'SILTest'.
 *
 * Model version                  : 1.66
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Thu Dec  5 14:05:30 2019
 *
 * Target selection: cfs_ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_eci_interface_h_
#define RTW_HEADER_eci_interface_h_
#include "SILTest.h"                   /* Model's header file */
#include "SILTest_private.h"
#include "sil_app_msgids.h"            /* FSW-provided header file */
#include "sil_app_perfids.h"           /* FSW-provided header file */

/*
 * Auto generated eci_interface.h for model: SILTest
 *
 *
 * Description:
 *
 * For more information:
 *   o Simulink Coder User's Guide
 *   o Embedded Coder User's Guide
 *   o CFS Target User's Guide
 *
 */
#define ECI_PARAM_TBL_DEFINED          1

/* Begin parameter table definition */
Tbl_b *Tbl;
static ECI_Tbl_t ECI_ParamTable[] = {
  {
    &(Tbl),
    "Tbl",
    "SILTest app's Tbl table",
    "Tbl.tbl",
    sizeof(Tbl_b),
    NULL
  },

  { 0, 0, 0, 0, 0 }
};

/* End parameter table definition */

/* Code Revision Identifier */
#define ECI_APP_REVISION_NUMBER        "test"
#define MODEL_NAME_LEN                 (8)
#if MODEL_NAME_LEN > OS_MAX_API_NAME
#error Model name SILTest must be less than OS_MAX_API_NAME characters
#endif

#define ECI_FLAG_MID                   SILTEST_FDC_MID
#define ECI_CMD_MID                    SILTEST_CMD_MID
#define ECI_PERF_ID                    SILTEST_PERF_ID
#define ECI_TICK_MID                   SILTEST_TICK_MID
#define ECI_HK_MID                     SILTEST_HK_MID
#define ECI_APP_MAIN                   siltest_AppMain
#define ECI_APP_NAME_UPPER             "SILTEST"
#define ECI_APP_NAME_LOWER             "siltest"
#define ECI_CMD_PIPE_NAME              "SILTEST_CMD_PIPE"
#define ECI_DATA_PIPE_NAME             "SILTEST_DATA_PIPE"

/* Begin sent messages definition */

/* Place each output signal that is a bus into the Send Table */
static ECI_Msg_t ECI_MsgSnd[] = {
  { AYNCMSGBUS_AYNCMSGBUS_S_MID, &AyncMsgBus_s, sizeof(AyncMsgBus), NULL,
    &cmsgFlag_SILTest_60 },

  { CDSDATABUS_CDSDATABUS_S_MID, &CdsDataBus_s, sizeof(CdsDataBus), NULL, NULL },

  { CONDITIONALMSGBUS_CONDITIONALMSGBUS_S_MID, &ConditionalMsgBus_s, sizeof
    (ConditionalMsgBus), NULL, NULL },

  { EVENTMSGBUS_EVENTMSGBUS_S_MID, &EventMsgBus_s, sizeof(EventMsgBus), NULL,
    NULL },

  { PERIODICMSGBUS_PERODICMSGBUS_S_MID, &PerodicMsgBus_s, sizeof(PeriodicMsgBus),
    NULL, &cmsgFlag_SILTest_5 },

  { STATUSFLAGBUS_STATUSFLAGBUS_S_MID, &StatusFlagBus_s, sizeof(StatusFlagBus),
    NULL, NULL },

  { TIMEBUS_TIMEBUS_S_MID, &TimeBus_s, sizeof(TimeBus), NULL, NULL },

  { 0, NULL, 0, NULL, NULL }
};

/* End sent messages definition */

/* Begin received messages definition */
/* Specify Queue sizes for Command Messages */
static InCmdBus InCmdBus_s_queue[ECI_CMD_MSG_QUEUE_SIZE];

/* Place each input signal that is a bus into the Receive Table */
static ECI_Msg_t ECI_MsgRcv[] = {
  { INCMDBUS_INCMDBUS_S_MID, &InCmdBus_s, sizeof(InCmdBus), &InCmdBus_s_queue[0],
    NULL },

  { INTLMBUS_INTLMBUS_S_MID, &InTlmBus_s, sizeof(InTlmBus), NULL, NULL },

  { 0, NULL, 0, NULL, NULL }
};

/* End received messages definition */

/* Begin events definition */
#define ECI_EVENT_TABLE_DEFINED        1

/* Create array of structures with error type, pointer to observable signal location,
   the location comment, and the event message */
static const ECI_Evs_t ECI_Events[] = {
  /* Event for block: SILTest/EventMessage_Test/CFS_Event */
  { ECI_EVENT_3_DATA,
    &SILTest_ConstP.CFS_Event_event_id,
    &SILTest_ConstP.pooled6,
    &SILTest_ConstP.pooled3,
    &evFlag_SILTest_7,
    SILTest_ConstP.CFS_Event_event_fmtstring,
    "SILTest/EventMessage_Test/CFS_Event",
    &evData_SILTest_7[0],
    &evData_SILTest_7[1],
    &evData_SILTest_7[2],
    0,
    0
  },

  /* Event for block: SILTest/EventMessage_Test/CFS_Event1 */
  { ECI_EVENT_1_DATA,
    &SILTest_ConstP.CFS_Event1_event_id,
    &SILTest_ConstP.pooled6,
    &SILTest_ConstP.pooled3,
    &evFlag_SILTest_125,
    SILTest_ConstP.CFS_Event1_event_fmtstring,
    "SILTest/EventMessage_Test/CFS_Event1",
    &evData_SILTest_125[0],
    0,
    0,
    0,
    0
  },

  { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }
};

/* End events definition */

/* Begin status flag definition */
#define ECI_FLAG_TABLE_DEFINED         1
#define ECI_FLAG_MAX_ID                1

/* Create array of FDC structures with id and flag */
static const ECI_Flag_t ECI_Flags[] = {
  /* Event for block: SILTest/StatusFlag_Test/CFS_Status_Flag */
  { &SILTest_ConstP.pooled6,
    &fdcFlag_6
  },

  { 0, 0 }
};

/* End status flag definition */

/* GNC time is used in model code */
#define ECI_STEP_TIMESTAMP_DEFINED

/* Begin CDS definition */
#define ECI_CDS_TABLE_DEFINED          1

/* Create array of structures with data to be managed by CDS */
static const ECI_Cds_t ECI_CdsTable[] = {
  { "double_accumulator_state",
    8,
    &double_accumulator_state,
  },

  { "uint8_counter_state",
    1,
    &uint8_counter_state,
  },

  { NULL, 0, NULL }
};

/* End CDS definition */

/* model initialization function */
#define ECI_INIT_FCN \
 SILTest_initialize();

/* step function.  Single rate (non-reusable interface) */
#define ECI_STEP_FCN \
 SILTest_step();

/* Get model outputs here */
#define ECI_TERM_FCN                   SILTest_terminate();
#endif                                 /* RTW_HEADER_eci_interface_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

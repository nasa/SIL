/*
 * File: ConditionalMsgBus.h
 *
 * Code generated for Simulink model 'SILTest'.
 *
 * Model version                  : 1.66
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Tue Dec 17 09:29:03 2019
 *
 * Target selection: cfs_ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_ConditionalMsgBus_h_
#define RTW_HEADER_ConditionalMsgBus_h_
#include "rtwtypes.h"

/* No description provided */
typedef struct {
  /* Flag indicating if periodic message was sent this cycle */
  boolean_T sent_periodic_message;

  /* Cycle counter triggering sending of periodic message */
  uint8_T cycle_counter;

  /* Flag indicating if asynchronous message was sent this cycle */
  boolean_T sent_asyc_message;

  /* Input value triggering sending of async message */
  uint8_T conditional_value;
} ConditionalMsgBus;

#endif                                 /* RTW_HEADER_ConditionalMsgBus_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

/*
 * File: CCSDS_TlmHdr_b.h
 *
 * Code generated for Simulink model 'SILTest'.
 *
 * Model version                  : 1.66
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Thu Dec  5 14:05:30 2019
 *
 * Target selection: cfs_ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_CCSDS_TlmHdr_b_h_
#define RTW_HEADER_CCSDS_TlmHdr_b_h_
#include "rtwtypes.h"

/* CCSDS Primary and Telemetry Secondary header */
typedef struct {
  /* Packet identifier including MessageID */
  uint8_T StreamID[2];

  /* Bitfield containing packet sequence information */
  uint8_T Sequence[2];
  uint8_T PktLen[2];

  /* Seconds field of timestamp. Formatted as array to avoid padding in header */
  uint16_T Time_sec[2];
  uint16_T Time_subsec;
} CCSDS_TlmHdr_b;

#endif                                 /* RTW_HEADER_CCSDS_TlmHdr_b_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

/*
 * File: AyncMsgBus.h
 *
 * Code generated for Simulink model 'SILTest'.
 *
 * Model version                  : 1.66
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Tue Dec 17 09:29:03 2019
 *
 * Target selection: cfs_ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_AyncMsgBus_h_
#define RTW_HEADER_AyncMsgBus_h_
#include "rtwtypes.h"

/* No description provided */
typedef struct {
  /* Will only ever see conditional value here */
  uint8_T conditional_value;
} AyncMsgBus;

#endif                                 /* RTW_HEADER_AyncMsgBus_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

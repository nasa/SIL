/*
 * Trial License - for use to evaluate programs for possible purchase as
 * an end-user only.
 *
 * File: SILTest.h
 *
 * Code generated for Simulink model 'SILTest'.
 *
 * Model version                  : 1.20
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Fri Jul 26 10:44:53 2019
 *
 * Target selection: cfs_ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_SILTest_h_
#define RTW_HEADER_SILTest_h_
#include <stddef.h>
#include <string.h>
#ifndef SILTest_COMMON_INCLUDES_
# define SILTest_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "eci_app.h"
#endif                                 /* SILTest_COMMON_INCLUDES_ */

#include "SILTest_types.h"
#include "eci_app.h"                   /* CSL Header file */

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

/* Block signals (default storage) */
typedef struct {
  OutBus_2_b BusCreator;               /* '<Root>/Bus Creator' */
  real_T Field4;                       /* '<Root>/CFS_Time' */
  boolean_T DataTypeConversion;        /* '<Root>/Data Type Conversion' */
  boolean_T DataTypeConversion2;       /* '<Root>/Data Type Conversion2' */
  boolean_T DataTypeConversion1;       /* '<Root>/Data Type Conversion1' */
} B_SILTest_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  int32_T CFS_Conditional_Msg_busSize; /* '<Root>/CFS_Conditional_Msg' */
} DW_SILTest_T;

/* Constant parameters (default storage) */
typedef struct {
  /* Expression: event_mask
   * Referenced by: '<Root>/CFS_Event'
   */
  uint32_T CFS_Event_event_mask;

  /* Pooled Parameter (Expression: )
   * Referenced by:
   *   '<Root>/CFS_Event'
   *   '<Root>/CFS_Status_Flag'
   */
  uint8_T pooled1;

  /* Computed Parameter: CFS_Event_event_type
   * Referenced by: '<Root>/CFS_Event'
   */
  uint8_T CFS_Event_event_type;

  /* Expression: fmt_string
   * Referenced by: '<Root>/CFS_Event'
   */
  uint8_T CFS_Event_event_fmtstring[19];
} ConstP_SILTest_T;

/* Real-time Model Data Structure */
struct tag_RTM_SILTest_T {
  const char_T *errorStatus;
};

/* Block signals (default storage) */
extern B_SILTest_T SILTest_B;

/* Block states (default storage) */
extern DW_SILTest_T SILTest_DW;

/* External data declarations for dependent source files */
extern const InBus_1_b SILTest_rtZInBus_1_b;/* InBus_1_b ground */
extern const OutBus_2_b SILTest_rtZOutBus_2_b;/* OutBus_2_b ground */
extern const OutBus_1_b SILTest_rtZOutBus_1_b;/* OutBus_1_b ground */

/* Constant parameters (default storage) */
extern const ConstP_SILTest_T SILTest_ConstP;

/*
 * Exported States
 *
 * Note: Exported states are block states with an exported global
 * storage class designation.  Code generation will declare the memory for these
 * states and exports their symbols.
 *
 */
extern real_T evData_SILTest_7[5];     /* '<Root>/CFS_Event' */
extern boolean_T cmsgFlag_SILTest_5;   /* '<Root>/CFS_Conditional_Msg' */
extern boolean_T evFlag_SILTest_7;     /* '<Root>/CFS_Event' */
extern boolean_T fdcFlag_6;            /* '<Root>/CFS_Status_Flag' */

/* Model entry point functions */
extern void SILTest_initialize(void);
extern void SILTest_step(void);
extern void SILTest_terminate(void);

/* Exported data declaration */

/* Declaration of data with custom storage class cfsTlmMessage */
extern InBus_1_b InBus1_s;
extern OutBus_1_b OutBus1_s;
extern OutBus_2_b OutBus2_s;

/* Real-time Model object */
extern RT_MODEL_SILTest_T *const SILTest_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'SILTest'
 */
#endif                                 /* RTW_HEADER_SILTest_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

/*
 * File: SILTest.h
 *
 * Code generated for Simulink model 'SILTest'.
 *
 * Model version                  : 1.66
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Thu Dec  5 14:05:30 2019
 *
 * Target selection: cfs_ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_SILTest_h_
#define RTW_HEADER_SILTest_h_
#include <string.h>
#ifndef SILTest_COMMON_INCLUDES_
# define SILTest_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "eci_app.h"
#endif                                 /* SILTest_COMMON_INCLUDES_ */

#include "SILTest_types.h"
#include "eci_app.h"                   /* CSL Header file */

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

/* Block signals (default storage) */
typedef struct {
  real_T evt1_value1;                  /* '<S3>/toDouble' */
  real_T evt1_value2;                  /* '<S3>/Gain' */
  real_T evt1_value3;                  /* '<S3>/Gain1' */
  PeriodicMsgBus BusCreator2;          /* '<S2>/Bus Creator2' */
  AyncMsgBus BusCreator1;              /* '<S2>/Bus Creator1' */
  boolean_T Compare;                   /* '<S12>/Compare' */
  boolean_T Compare_h;                 /* '<S11>/Compare' */
  boolean_T Compare_g;                 /* '<S14>/Compare' */
  boolean_T FixPtRelationalOperator;   /* '<S15>/FixPt Relational Operator' */
  boolean_T Compare_l;                 /* '<S16>/Compare' */
} B_SILTest_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real_T DelayInput1_DSTATE;           /* '<S15>/Delay Input1' */
  real_T UnitDelay_DSTATE;             /* '<S7>/Unit Delay' */
  int32_T PeriodicMessage_busSize;     /* '<S2>/PeriodicMessage' */
  int32_T AsyncMessage_busSize;        /* '<S2>/AsyncMessage' */
  uint8_T UnitDelay_DSTATE_f;          /* '<S13>/Unit Delay' */
  uint8_T UnitDelay_DSTATE_k;          /* '<S10>/Unit Delay' */
} DW_SILTest_T;

/* Constant parameters (default storage) */
typedef struct {
  /* Pooled Parameter (Expression: event_mask)
   * Referenced by:
   *   '<S3>/CFS_Event'
   *   '<S3>/CFS_Event1'
   */
  uint32_T pooled3;

  /* Computed Parameter: CFS_Event_event_id
   * Referenced by: '<S3>/CFS_Event'
   */
  uint8_T CFS_Event_event_id;

  /* Pooled Parameter (Expression: )
   * Referenced by:
   *   '<S3>/CFS_Event'
   *   '<S3>/CFS_Event1'
   *   '<S5>/CFS_Status_Flag'
   */
  uint8_T pooled6;

  /* Expression: fmt_string
   * Referenced by: '<S3>/CFS_Event'
   */
  uint8_T CFS_Event_event_fmtstring[45];

  /* Computed Parameter: CFS_Event1_event_id
   * Referenced by: '<S3>/CFS_Event1'
   */
  uint8_T CFS_Event1_event_id;

  /* Expression: fmt_string
   * Referenced by: '<S3>/CFS_Event1'
   */
  uint8_T CFS_Event1_event_fmtstring[36];
} ConstP_SILTest_T;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  ParamTblBus ParamTblBus_l;           /* '<Root>/ParamTblBus' */
} ExtY_SILTest_T;

/* Real-time Model Data Structure */
struct tag_RTM_SILTest_T {
  const char_T *errorStatus;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
  } Timing;
};

/* Block signals (default storage) */
extern B_SILTest_T SILTest_B;

/* Block states (default storage) */
extern DW_SILTest_T SILTest_DW;

/* External outputs (root outports fed by signals with default storage) */
extern ExtY_SILTest_T SILTest_Y;

/* External data declarations for dependent source files */
extern const InTlmBus SILTest_rtZInTlmBus;/* InTlmBus ground */
extern const InCmdBus SILTest_rtZInCmdBus;/* InCmdBus ground */
extern const CdsDataBus SILTest_rtZCdsDataBus;/* CdsDataBus ground */
extern const AyncMsgBus SILTest_rtZAyncMsgBus;/* AyncMsgBus ground */
extern const ConditionalMsgBus SILTest_rtZConditionalMsgBus;/* ConditionalMsgBus ground */
extern const PeriodicMsgBus SILTest_rtZPeriodicMsgBus;/* PeriodicMsgBus ground */
extern const EventMsgBus SILTest_rtZEventMsgBus;/* EventMsgBus ground */
extern const StatusFlagBus SILTest_rtZStatusFlagBus;/* StatusFlagBus ground */
extern const TimeBus SILTest_rtZTimeBus;/* TimeBus ground */

/* Constant parameters (default storage) */
extern const ConstP_SILTest_T SILTest_ConstP;

/*
 * Exported States
 *
 * Note: Exported states are block states with an exported global
 * storage class designation.  Code generation will declare the memory for these
 * states and exports their symbols.
 *
 */
extern real_T evData_SILTest_7[5];     /* '<S3>/CFS_Event' */
extern real_T evData_SILTest_125[5];   /* '<S3>/CFS_Event1' */
extern boolean_T cmsgFlag_SILTest_5;   /* '<S2>/PeriodicMessage' */
extern boolean_T cmsgFlag_SILTest_60;  /* '<S2>/AsyncMessage' */
extern boolean_T evFlag_SILTest_7;     /* '<S3>/CFS_Event' */
extern boolean_T evFlag_SILTest_125;   /* '<S3>/CFS_Event1' */
extern boolean_T fdcFlag_6;            /* '<S5>/CFS_Status_Flag' */

/* Model entry point functions */
extern void SILTest_initialize(void);
extern void SILTest_step(void);
extern void SILTest_terminate(void);

/* Exported data declaration */

/* Declaration of data with custom storage class cfsCmdMessage */
extern InCmdBus InCmdBus_s;

/* Declaration of data with custom storage class cfsTlmMessage */
extern AyncMsgBus AyncMsgBus_s;
extern CdsDataBus CdsDataBus_s;
extern ConditionalMsgBus ConditionalMsgBus_s;
extern EventMsgBus EventMsgBus_s;
extern InTlmBus InTlmBus_s;
extern PeriodicMsgBus PerodicMsgBus_s;
extern StatusFlagBus StatusFlagBus_s;
extern TimeBus TimeBus_s;

/* Real-time Model object */
extern RT_MODEL_SILTest_T *const SILTest_M;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S1>/toDouble' : Eliminate redundant data type conversion
 * Block '<S2>/Data Type Conversion' : Eliminate redundant data type conversion
 * Block '<S2>/Data Type Conversion1' : Eliminate redundant data type conversion
 * Block '<S3>/Data Type Conversion2' : Eliminate redundant data type conversion
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'SILTest'
 * '<S1>'   : 'SILTest/CDS_Test'
 * '<S2>'   : 'SILTest/ConditionalMessaging_Test'
 * '<S3>'   : 'SILTest/EventMessage_Test'
 * '<S4>'   : 'SILTest/ParamTbl_Test'
 * '<S5>'   : 'SILTest/StatusFlag_Test'
 * '<S6>'   : 'SILTest/Time_Test'
 * '<S7>'   : 'SILTest/CDS_Test/Accumulator'
 * '<S8>'   : 'SILTest/CDS_Test/CDSAccumulator'
 * '<S9>'   : 'SILTest/CDS_Test/CDSCounter'
 * '<S10>'  : 'SILTest/CDS_Test/Counter'
 * '<S11>'  : 'SILTest/ConditionalMessaging_Test/Compare To Constant'
 * '<S12>'  : 'SILTest/ConditionalMessaging_Test/Compare To Zero'
 * '<S13>'  : 'SILTest/ConditionalMessaging_Test/Counter'
 * '<S14>'  : 'SILTest/EventMessage_Test/Compare To Constant'
 * '<S15>'  : 'SILTest/EventMessage_Test/Detect Change'
 * '<S16>'  : 'SILTest/StatusFlag_Test/Compare To Constant'
 */
#endif                                 /* RTW_HEADER_SILTest_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

/*
 * File: TimeBus.h
 *
 * Code generated for Simulink model 'SILTest'.
 *
 * Model version                  : 1.66
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Thu Dec  5 14:05:30 2019
 *
 * Target selection: cfs_ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_TimeBus_h_
#define RTW_HEADER_TimeBus_h_
#include "rtwtypes.h"

/* No description provided */
typedef struct {
  real_T fsw_time;
  real_T elapsed_sim_time;
} TimeBus;

#endif                                 /* RTW_HEADER_TimeBus_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

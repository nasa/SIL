/*
 * File: EventMsgBus.h
 *
 * Code generated for Simulink model 'SILTest'.
 *
 * Model version                  : 1.66
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Tue Dec 17 09:29:03 2019
 *
 * Target selection: cfs_ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_EventMsgBus_h_
#define RTW_HEADER_EventMsgBus_h_
#include "rtwtypes.h"

/* No description provided */
typedef struct {
  /* Flag indicating if event1 was sent this cycle */
  boolean_T sending_event1;

  /* Flag indicating if event2 was sent this cycle */
  boolean_T sending_event2;

  /* Value of first argument in event1 */
  real_T evt1_value1;

  /* Value of second argument in event1 */
  real_T evt1_value2;

  /* Value of thrid argument in event1 */
  real_T evt1_value3;

  /* Value of first argument in event2 */
  real_T evt2_value1;
} EventMsgBus;

#endif                                 /* RTW_HEADER_EventMsgBus_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
